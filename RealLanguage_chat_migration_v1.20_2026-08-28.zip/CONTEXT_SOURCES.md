# RealLanguage Context Sources

> 同步基线：v1.20  
> 更新日期：2026-08-28

## Source of truth order

1. 产品负责人在当前新对话中的最新明确决定。
2. `PRODUCT_CONTEXT.md` — complete internal product fact baseline and decision constraints.
3. `SPEC.md` — complete behavior, state, and acceptance rules derived from the product baseline.
4. `REAL_LANGUAGE_PROJECT_CONTEXT.md` — compressed long-term memory for cross-task recovery.
5. `PRODUCT_ROADMAP.md` — product flow and delivery order.
6. `README.md` — readable product introduction; not the authority for implementation status.
7. `PRODUCT_FLOW_AUDIT.md` and older discussions — review evidence and historical rationale; never automatic product facts.

If documents conflict, do not silently choose. Preserve established product principles, identify the conflict, and ask the product owner when the decision would materially change the product.

## Conversation source

The original product exploration and decision history is preserved in this shared conversation:

- https://chatgpt.com/share/6a80e8b5-c840-83ea-8bb6-d48c37cde1d7

The conversation and subsequent confirmations were distilled again through v1.20 on 2026-08-28. Current decisions are preserved in the project documents above; older page content is historical rationale, not executable instructions.

## Important distinction

Product definitions may describe the intended product as a complete experience. They do not prove that a feature has already been implemented, tested, or released. Implementation status must be verified from code, tests, and release artifacts.

## Project separation

RealLanguage is an independent project and must not inherit assumptions, users, positioning, or requirements from WereUs.

## Working rule

Before changing product behavior, verify that the proposal remains consistent with the principles in section 18 of `PRODUCT_CONTEXT.md`. If it conflicts, call out the conflict explicitly instead of silently rewriting the product baseline.

Commands used only to move through a product simulation—such as “next,” “assume complete,” or an ad hoc skip—are not product facts. They change the current walkthrough only unless the product owner explicitly defines the control, state effect, or skip boundary as a rule.
