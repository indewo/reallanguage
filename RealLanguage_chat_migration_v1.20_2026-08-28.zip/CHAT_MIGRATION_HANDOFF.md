# RealLanguage 新聊天迁移交接包

> 交接基线：v1.20  
> 打包日期：2026-08-28  
> 工作目录：`/Users/eric/Documents/英语学习APP`  
> 用途：迁移到新的聊天窗口时恢复完整上下文。本文只负责导航和交接，不替代任何详细产品文档。

## 1. 新聊天必须先做什么

开始任何讨论、设计或修改前，必须完整读取以下文件：

1. `CONTEXT_SOURCES.md`
2. `PRODUCT_CONTEXT.md`
3. `SPEC.md`
4. `REAL_LANGUAGE_PROJECT_CONTEXT.md`
5. `PRODUCT_ROADMAP.md`
6. `README.md`
7. `PRODUCT_FLOW_AUDIT.md`
8. `CHAT_MIGRATION_HANDOFF.md`

不得仅凭本交接摘要恢复产品规则。详细行为、状态和验收条件必须回到原文核对。

## 2. 信息冲突优先级

1. 产品负责人在新聊天中的最新明确决定；
2. `PRODUCT_CONTEXT.md`；
3. `SPEC.md`；
4. `REAL_LANGUAGE_PROJECT_CONTEXT.md`；
5. `PRODUCT_ROADMAP.md`；
6. `README.md`；
7. `PRODUCT_FLOW_AUDIT.md` 和旧讨论。

遇到实质冲突不得静默选择或自行补全，必须指出冲突并交由产品负责人确认。

## 3. 当前项目状态

- 当前统一文档基线为 v1.20，日期为 2026-08-28。
- 当前文件保存的是已经确认的产品规则，不代表对应功能已经开发、测试或发布。
- RealLanguage 是独立项目，不继承其他产品的假设或规则。
- 当前阶段仍以产品设计和流程验证为主，尚未进入完整工程实现。
- 产品模拟中的“下一步”“假设完成”“跳过场景”“跳过环节”等操作，只用于快速测试当次流程；除非产品负责人明确把它定义为按钮、状态或规则，否则不得写入正式产品事实。

## 4. 现有文档职责

| 文档 | 职责 |
|---|---|
| `PRODUCT_CONTEXT.md` | 已确认的产品事实、原则和边界，是产品事实基线。 |
| `SPEC.md` | 详细行为、状态、交互、异常处理和验收规则。 |
| `REAL_LANGUAGE_PROJECT_CONTEXT.md` | 跨聊天恢复使用的压缩长期记忆；不能替代前两份文件。 |
| `PRODUCT_ROADMAP.md` | 产品流程、阶段关系和交付顺序。 |
| `README.md` | 面向读者的产品和项目介绍，不是实现状态的权威来源。 |
| `CONTEXT_SOURCES.md` | 文档优先级、历史来源和工作规则。 |
| `PRODUCT_FLOW_AUDIT.md` | 历史审查、风险和建议；未被确认的建议不是产品事实。 |

## 5. 已讨论但尚未创建的文档体系

以下是下一阶段需要处理的文档工作清单，不代表其中的技术方案已经确定：

| 层级 | 文档 | 目的 | 建议顺序 |
|---|---|---|---:|
| 产品范围 | `MVP_SCOPE.md` | 明确第一版做什么、不做什么以及延期内容。 | 1 |
| 页面设计 | `SCREEN_MAP.md` | 页面、导航、入口出口和返回关系。 | 2 |
| 页面设计 | `SCREEN_SPEC.md` | 逐页布局、内容、按钮、状态、交互和异常界面。 | 3 |
| 总体技术 | `ARCHITECTURE.md` | 客户端、服务端、数据库、AI、语音、手写识别和存储的总体架构。 | 4 |
| 数据设计 | `DATA_MODEL.md` | 内容、章节、重点句、词义、句式、错题、状态和回顾队列的数据关系。 | 5 |
| AI 设计 | `AI_CONTRACTS.md` | AI 输入输出、拆分、生成、审核、反馈、评分和失败降级规范。 | 6 |
| 详细技术 | `DESIGN.md` | 模块、接口、状态机、数据流和核心功能的实现设计。 | 7 |
| 开发规范 | `CONTRIBUTING.md` | 目录、代码、提交、测试以及 AI 编码约束。 | 8 |
| 视觉设计 | `DESIGN_SYSTEM.md` | 横屏栅格、字体、颜色、间距、组件、高亮、触控和无障碍规范。 | 后续 |
| 语音设计 | `AUDIO_SPEECH_SPEC.md` | TTS、录音、识别、发音评价、静音和逐词高亮同步。 | 后续 |
| 架构决策 | `ADR.md` | 记录已经作出的重要技术决定、原因、代价和替代方案。 | 随开发累积 |
| 技术讨论 | `RFC.md` | 讨论尚未确定且存在多个候选方案的复杂技术问题。 | 按需 |
| 测试 | `TEST_PLAN.md` | 功能、设备、横屏、语音、AI 输出、数据和回归测试。 | 原型后 |
| 用户验证 | `USER_TEST_PLAN.md` | 测试对象、任务、观察指标和访谈记录。 | 可用原型后 |
| 数据指标 | `ANALYTICS_PLAN.md` | 埋点、漏斗、完成率、正确率、复习效果和留存指标。 | 内测前 |
| 隐私安全 | `PRIVACY_SECURITY.md` | 录音、文本、权限、数据保留、删除、加密和用户同意。 | 内测前 |
| 商业模式 | `MONETIZATION_PLAN.md` | 免费额度、订阅、AI 成本、单位经济和退款原则。 | 公测前 |
| 上线运营 | `LAUNCH_CHECKLIST.md` | 上架、审核、监控、客服、故障、备份和模型降级。 | 上线前 |

`PRODUCT_CONTEXT.md` 与 `SPEC.md` 合起来已经承担详细 PRD 的主要职责，当前不需要额外创建一份内容重复的 `PRD.md`。

`ADR.md` 记录已经决定的架构事项；`RFC.md` 用于尚未决定、需要比较的方案，两者不得混用。

## 6. 新聊天可直接发送的首条指令

```text
继续 RealLanguage 产品设计。

当前工作目录：
/Users/eric/Documents/英语学习APP

开始工作前，请完整阅读：
1. CONTEXT_SOURCES.md
2. PRODUCT_CONTEXT.md
3. SPEC.md
4. REAL_LANGUAGE_PROJECT_CONTEXT.md
5. PRODUCT_ROADMAP.md
6. README.md
7. PRODUCT_FLOW_AUDIT.md
8. CHAT_MIGRATION_HANDOFF.md

当前统一基线是 v1.20（2026-08-28）。

发生冲突时按 CONTEXT_SOURCES.md 的优先级处理。不要根据旧讨论自行补充规则；PRODUCT_FLOW_AUDIT.md 中未被确认的建议不自动成为产品事实。产品模拟中用于快速推进的“下一步”“假设完成”“跳过”等指令，不自动成为产品规则。

请先不要修改任何文件。阅读完成后，用简短语言告诉我：
1. 你理解的产品定位和三条入口；
2. 当前普通学习、统一回顾、词汇本和句式本的关系；
3. 当前文档版本；
4. 已有文档与下一阶段待创建文档分别有哪些。

等我确认理解正确后再继续。
```

## 7. 完整性校验

打包时七份权威项目文档共 2,861 行。SHA-256：

```text
2e98afd61e306a7e30a2d2a803dbfdf18133b2fd872b8950be7dcf104de79402  CONTEXT_SOURCES.md
aee280742ab0330473fbc14809ebf244fa8ec9d38a0a03ed2e52cd0435345acf  PRODUCT_CONTEXT.md
17aa779c3fc08e1a6c590deb2b804738097a00f171babc5cc098dfb2eec74595  SPEC.md
20c8e4809b6bf764f56bf3809648930495c16648b57029ce4a3a928e40ef2dee  REAL_LANGUAGE_PROJECT_CONTEXT.md
0292861cb2c708becf1e0f1275b91f14fce21f08708a70ed232c01f0e8c38485  PRODUCT_ROADMAP.md
d143c54200457cd3393177192c808665e35f34cb8ecc568475b8209e9cb6e92a  README.md
6ea082b025600b68d642558c621764ed48f1fc822df83ac2e3df34489f0fc223  PRODUCT_FLOW_AUDIT.md
```

校验值用于确认迁移包内的原始文档没有被截断或意外改写。`CHAT_MIGRATION_HANDOFF.md` 是本次新增的交接导航文件，不计入上述 v1.20 原文校验。
